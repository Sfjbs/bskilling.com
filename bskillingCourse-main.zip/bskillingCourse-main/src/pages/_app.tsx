import FixedFooterBar from "components/fixedFooterBar";
import Layout from "components/Layout";
import { MyProvider } from "context/PageContext";
import { motion } from "framer-motion";
import useChat from "modules/leadChat/zustand";
import { AppProps } from "next/app";
import Head from "next/head";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import "../../style/globals.css";

function MyApp({ Component, pageProps }: AppProps) {
  const route = useRouter();
  const {
    floatWindowMode,
    isChatFormVisible,
    setFloatWindowMode,
    setupSocket,
    instanceState,
    closeChat,
  } = useChat();
  const [chatIconVisible, setChatIconVisible] = useState(false);
  const [showFixedFooter, setShowFixedFooter] = useState(false);

  useEffect(() => {
    function handleScroll() {
      const scrollPosition = window.scrollY;
      const halfScreenHeight = window.innerHeight / 4.9;

      if (scrollPosition >= halfScreenHeight) {
        setShowFixedFooter(true);
      } else {
        setShowFixedFooter(false);
      }
    }

    // Add the event listener when the component mounts
    window.addEventListener("scroll", handleScroll);

    // Clean up the event listener when the component unmounts
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  useEffect(() => {
    const currentTime = new Date();
    const currentHour = currentTime.getHours();
    const currentDay = currentTime.getDay(); // Sunday: 0, Monday: 1, ..., Saturday: 6

    if (
      currentDay >= 1 && // Monday
      currentDay <= 5 && // Friday
      currentHour >= 10 &&
      currentHour < 18
    ) {
      const timeout = setTimeout(() => {
        setChatIconVisible(true);
      }, 4000);

      return () => clearTimeout(timeout);
    } else {
      setChatIconVisible(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFloatWindowMode("drop-a-query");
    }, 4000);

    return () => clearTimeout(timer);
  }, [route.pathname]);
  return (
    <MyProvider>
      <Layout>
        <Head>
          <title>bSkilling</title>
          <meta
            name="bSkilling"
            content="bSkilling is a pioneer in technology training and we focus on
                offering top-notch IT and fintech education and skill
                development programs. We work hard to help people and
                organizations with the information and skills necessary to
                prosper in the quickly changing digital landscape. We aim and
                deliver excellence in all fields."
          />
          <meta
            name="p:domain_verify"
            content="7bb84546e514612864b5b9d71d1649e4"
          />
          <link rel="icon" href="/favicon.png" />
          <script
            async
            src="https://www.googletagmanager.com/gtag/js?id=G-3PVZC9K8BH"
          ></script>
          <script
            dangerouslySetInnerHTML={{
              __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'G-3PVZC9K8BH');
            `,
            }}
          />
        </Head>

        <Component {...pageProps} />
        {/* <FloatWindow /> */}

        {showFixedFooter && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.1, ease: "easeIn" }}
          >
            <FixedFooterBar />
          </motion.div>
        )}
      </Layout>
    </MyProvider>
  );
}

export default MyApp;

type IFloatWindowMode = "none" | "chat" | "drop-a-query";

export default IFloatWindowMode;

interface ILeadInfo {
  userId: string;
  instanceId: string;
}

export default ILeadInfo;

interface IInitiateChatError {
  err: string
}

export default IInitiateChatError;

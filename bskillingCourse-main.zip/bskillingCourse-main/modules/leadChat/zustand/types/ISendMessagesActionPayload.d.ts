interface ISendMessagesActionPayload {
  text: string;
  createdAt: Date;
}

export default ISendMessagesActionPayload;
